import SearchBox from './search-box';

export default SearchBox;
