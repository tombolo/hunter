import Toolbar from './toolbar';
import './toolbar.scss';

export default Toolbar;
