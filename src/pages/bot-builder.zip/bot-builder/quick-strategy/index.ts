import QuickStrategy from './quick-strategy';

export default QuickStrategy;
