import BotBuilder from './bot-builder';
import './workspace.scss';

export default BotBuilder;
